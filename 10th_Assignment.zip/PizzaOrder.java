import java.awt.Color;

import javax.swing.*;

public class PizzaOrder extends JFrame{
	public PizzaOrder(){
		setSize(600,150);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Pizza Order");
		
		JPanel panel = new JPanel();
		JPanel panelA = new JPanel();
		JPanel panelB = new JPanel();
  
		JLabel label1 = new JLabel("Welcome to JAVA PIZZA! Choose pizza's category.");
		panelA.add(label1);
		
		JButton button1 = new JButton("COMBO PIZZA");
		JButton button2 = new JButton("POTATO PIZZA");
		JButton button3 = new JButton("BULGOGI PIZZA");
		panelB.add(button1);
		panelB.add(button2);
		panelB.add(button3);
		
		JLabel label2 = new JLabel("Quantity");
		JTextField field1 = new JTextField(10);
		panelB.add(label2);
		panelB.add(field1);
  
		panel.setBackground(Color.GREEN);
		panelA.setBackground(Color.PINK);
		panelB.setBackground(Color.YELLOW);
		
		panel.add(panelA);
		panel.add(panelB);
		add(panel);
		setVisible(true);
	}
	
	public static void main(String args[]){
		PizzaOrder o = new PizzaOrder();
	}
}